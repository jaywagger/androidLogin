package com.example.finalproject.login;

public class ModeState {
    int mode;

    public ModeState(int mode) {
        this.mode = mode;
    }

}
